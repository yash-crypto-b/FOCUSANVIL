
import { User, UserStats, DailyRecord } from '../types';

const USER_KEY = 'focusanvil_user';
const STATS_KEY = 'focusanvil_stats';
const DAILY_MSG_KEY = 'focusanvil_daily_msg';

// Simulate Backend Login / Signup - ENFORCES ZERO START
export const loginUser = (email: string, goal: string): { user: User, stats: UserStats } => {
  const now = new Date().toISOString();
  const todayStr = new Date().toISOString().split('T')[0];

  const newUser: User = {
    email,
    primaryGoal: goal,
    joinedAt: now,
    journeyStartDate: now,
    lastLoginAt: now,
    loginStreak: 1, // Day 1
  };

  // Initial ZERO stats - No inheritance
  const initialStats: UserStats = {
    coins: 0,
    xp: 0,
    streak: 1,
    deepWorkMinutes: 0,
    tasksCompleted: 0,
    level: 1,
    history: [
      {
        date: todayStr,
        focusMinutes: 0,
        tasksCompleted: 0,
        coinsEarned: 0,
        violations: 0,
        aborts: 0,
        productivityScore: 0
      }
    ]
  };

  localStorage.setItem(USER_KEY, JSON.stringify(newUser));
  localStorage.setItem(STATS_KEY, JSON.stringify(initialStats));
  
  return { user: newUser, stats: initialStats };
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(USER_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const getUserStats = (): UserStats | null => {
  const stored = localStorage.getItem(STATS_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const saveUserStats = (stats: UserStats) => {
  localStorage.setItem(STATS_KEY, JSON.stringify(stats));
};

export const updateUserProfile = (user: User) => {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

/**
 * Checks and updates the login streak.
 */
export const checkLoginStreak = (user: User): { updatedUser: User; missedDay: boolean } => {
  const today = new Date();
  const lastLogin = new Date(user.lastLoginAt);

  const todayStr = today.toDateString();
  const lastLoginStr = lastLogin.toDateString();
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toDateString();

  let updatedUser = { ...user };
  let missedDay = false;

  if (todayStr !== lastLoginStr) {
     // It's a new day login
     if (lastLoginStr === yesterdayStr) {
       // Logged in yesterday, increment streak
       updatedUser.loginStreak = (updatedUser.loginStreak || 0) + 1;
     } else if (lastLogin > yesterday) {
        // Already logged in today? (Should be caught by todayStr !== lastLoginStr, 
        // but handle case where lastLogin is technically 'today' but hours differ if logic changes)
        // do nothing
     } else {
       // Missed a day or more
       // If it wasn't the first day (streak > 0), it's a fail.
       if (updatedUser.loginStreak > 0) {
          missedDay = true;
       }
       updatedUser.loginStreak = 1; // Reset to 1 for today
     }
     
     updatedUser.lastLoginAt = new Date().toISOString();
     updateUserProfile(updatedUser);
  }

  return { updatedUser, missedDay };
};

export const getStoredDailyMessage = (): { date: string; text: string } | null => {
  const stored = localStorage.getItem(DAILY_MSG_KEY);
  return stored ? JSON.parse(stored) : null;
};

export const saveDailyMessage = (text: string) => {
  const data = {
    date: new Date().toDateString(),
    text
  };
  localStorage.setItem(DAILY_MSG_KEY, JSON.stringify(data));
};

export const shouldGenerateDailyMessage = (): boolean => {
  const stored = getStoredDailyMessage();
  const today = new Date().toDateString();
  return !stored || stored.date !== today;
};

/**
 * Records activity to the heatmap/history and updates real-time stats
 */
export const recordDailyActivity = (
  stats: UserStats, 
  activity: { 
    minutes?: number, 
    tasks?: number, 
    coins?: number, 
    violations?: number,
    aborts?: number
  }
): UserStats => {
  const todayStr = new Date().toISOString().split('T')[0];
  const newStats = { ...stats };
  
  // Find or create today's record
  let recordIndex = newStats.history.findIndex(h => h.date === todayStr);
  if (recordIndex === -1) {
    newStats.history.push({
      date: todayStr,
      focusMinutes: 0,
      tasksCompleted: 0,
      coinsEarned: 0,
      violations: 0,
      aborts: 0,
      productivityScore: 0
    });
    recordIndex = newStats.history.length - 1;
  }

  const record = newStats.history[recordIndex];
  
  if (activity.minutes) record.focusMinutes += activity.minutes;
  if (activity.tasks) record.tasksCompleted += activity.tasks;
  if (activity.coins) record.coinsEarned += activity.coins;
  if (activity.violations) record.violations += activity.violations;
  if (activity.aborts) record.aborts += activity.aborts;

  // Calculate Productivity Score (0-100)
  // Weighted formula:
  // +1 point per 2 minutes focus
  // +10 points per task
  // +1 point per 5 coins
  // -20 points per violation
  // -50 points per abort
  let rawScore = (record.focusMinutes / 2) + (record.tasksCompleted * 10) + (record.coinsEarned / 5);
  rawScore -= (record.violations * 20);
  rawScore -= (record.aborts * 50);

  // Clamp score
  record.productivityScore = Math.min(100, Math.max(0, Math.floor(rawScore)));

  saveUserStats(newStats);
  return newStats;
};
