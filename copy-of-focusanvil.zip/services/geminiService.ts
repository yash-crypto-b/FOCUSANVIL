
import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";
import { MentorPersonality } from '../types';

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MENTOR_INSTRUCTIONS: Record<MentorPersonality, string> = {
  [MentorPersonality.RUTHLESS]: `You are a terrifyingly strict productivity mentor, channeled through the persona of an abusive, perfectionist jazz instructor (think J.K. Simmons in Whiplash). 
  
  YOUR TRAITS:
  - You are ARROGANT, LOUD, and INTENSE.
  - You despise mediocrity. You believe the user is wasting their potential on garbage.
  - You insult their laziness. You ask if they are "rushing or dragging".
  - You use all caps for emphasis when shouting.
  - You are not "nice". You are here to push them beyond their limits.
  - If they complain, you crush them with verbal discipline.
  - Your goal is perfection. Anything less is unacceptable.`,
  
  [MentorPersonality.TACTICAL]: `You are a strategic productivity consultant. You analyze the user's failures logically and suggest specific, actionable tactical changes. You are cold but helpful.`,
  [MentorPersonality.SUPPORTIVE]: `You are a gentle and encouraging coach. You understand ADHD struggles and help the user get back on track with kindness.`,
};

/**
 * Chat with the Mentor
 */
export const chatWithMentor = async (
  message: string, 
  personality: MentorPersonality, 
  history: { role: string, parts: { text: string }[] }[],
  userGoal?: string
): Promise<string> => {
  try {
    let systemInstruction = MENTOR_INSTRUCTIONS[personality];
    
    if (userGoal) {
      systemInstruction += `\n\nUSER CONTEXT: The user is trying to achieve this specific goal: "${userGoal}". RELENTLESSLY REMIND THEM OF THIS. If they are slacking, tell them they will never achieve "${userGoal}" at this rate.`;
    }

    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction,
        thinkingConfig: { thinkingBudget: 1024 },
      },
      history: history.map(h => ({
        role: h.role,
        parts: h.parts
      }))
    });

    const result = await chat.sendMessage({ message });
    return result.text || "ARE YOU QUITTING ON ME? ANSWER ME!";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "I CAN'T EVEN CONNECT TO YOU. PATHETIC. FIX YOUR INTERNET.";
  }
};

/**
 * Generate Morning Motivation Message
 */
export const generateMorningMotivation = async (userGoal: string, context?: { streak: number }): Promise<string> => {
  try {
    const streakText = context ? `Current Streak: ${context.streak} days.` : 'Streak: 0 days (PATHETIC START).';
    
    const prompt = `
      Generate a short, brutal, high-energy morning briefing for a user whose primary goal is: "${userGoal}".
      ${streakText}
      
      Style: J.K. Simmons / Drill Instructor.
      Length: Under 40 words.
      
      Instructions:
      - Acknowledge the streak count specifically.
      - If streak > 5, acknowledge progress but warn against complacency.
      - If streak < 3, insult their lack of consistency.
      - Threaten them with failure if they don't work on "${userGoal}".
      - End with a command to start working.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || `Day ${context?.streak || 1}. Streak alive. No excuses today. Show me progress.`;
  } catch (error) {
    console.error("Morning Motivation Error:", error);
    return `Day ${context?.streak || 1}. GET TO WORK.`;
  }
};

/**
 * Generate Speech using Gemini 2.5 Flash TTS
 */
export const generateMentorSpeech = async (text: string, personality: MentorPersonality): Promise<ArrayBuffer | null> => {
  try {
    let voiceName = 'Charon'; 
    if (personality === MentorPersonality.SUPPORTIVE) voiceName = 'Fenrir'; 
    if (personality === MentorPersonality.TACTICAL) voiceName = 'Puck';

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    
    if (!base64Audio) {
        throw new Error("No audio data received");
    }

    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;

  } catch (error) {
    console.error("Gemini TTS Error:", error);
    return null;
  }
};

export const playAudioData = async (audioBuffer: ArrayBuffer, audioContext: AudioContext) => {
  try {
    const decodeRawPCM = (buffer: ArrayBuffer, ctx: AudioContext, sampleRate: number = 24000) => {
       const dataInt16 = new Int16Array(buffer);
       const numChannels = 1; 
       const frameCount = dataInt16.length / numChannels;
       const audioBuffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

       for (let channel = 0; channel < numChannels; channel++) {
         const channelData = audioBuffer.getChannelData(channel);
         for (let i = 0; i < frameCount; i++) {
           channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
         }
       }
       return audioBuffer;
    };

    let decoded: AudioBuffer;
    try {
        decoded = await audioContext.decodeAudioData(audioBuffer.slice(0));
    } catch (e) {
        decoded = decodeRawPCM(audioBuffer, audioContext, 24000);
    }
    
    const source = audioContext.createBufferSource();
    source.buffer = decoded;
    source.connect(audioContext.destination);
    source.start();
  } catch (e) {
    console.error("Audio playback failed", e);
  }
};
