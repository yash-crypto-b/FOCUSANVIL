import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService) {}

  async signup(dto: { email: string; password: string; primaryGoal?: string }) {
    const hash = await bcrypt.hash(dto.password, 12);

    // Transaction ensures User + Stats created together or fail
    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email: dto.email,
          passwordHash: hash,
          primaryGoal: dto.primaryGoal,
          journeyStartDate: new Date(),
          stats: {
            create: {
              coins: 0,
              xp: 0,
              streak: 1, // Day 1 starts now
              level: 1,
              totalFocusMins: 0
            }
          }
        },
        include: { stats: true }
      });
      
      return user;
    });
  }

  async validateUser(email: string, pass: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (user && (await bcrypt.compare(pass, user.passwordHash))) {
      // Update Last Login & Streak Logic here
      await this.checkLoginStreak(user.id, user.lastLoginAt);
      const { passwordHash, ...result } = user;
      return result;
    }
    return null;
  }

  private async checkLoginStreak(userId: string, lastLogin: Date) {
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);

    const isSameDay = now.toDateString() === lastLogin.toDateString();
    const isConsecutive = yesterday.toDateString() === lastLogin.toDateString();

    if (!isSameDay) {
      await this.prisma.user.update({
        where: { id: userId },
        data: { lastLoginAt: now }
      });

      if (isConsecutive) {
        await this.prisma.userStats.update({
          where: { userId },
          data: { streak: { increment: 1 } }
        });
      } else {
        // Broken Streak
        await this.prisma.userStats.update({
          where: { userId },
          data: { streak: 1 } // Reset to 1
        });
      }
    }
  }
}
