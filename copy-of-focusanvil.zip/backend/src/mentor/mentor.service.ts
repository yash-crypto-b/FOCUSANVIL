
import { Injectable } from '@nestjs/common';
import { GoogleGenAI, Modality } from '@google/genai';

@Injectable()
export class MentorService {
  private client: GoogleGenAI;

  constructor() {
    this.client = new GoogleGenAI({ apiKey: process.env.GOOGLE_GENAI_API_KEY });
  }

  async chat(message: string, userContext: string) {
    const systemInstruction = `
      You are a RUTHLESS productivity mentor (J.K. Simmons persona).
      USER CONTEXT: ${userContext}
      Be brief. Be harsh. Demand perfection.
    `;

    const response = await this.client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: message,
        config: { systemInstruction }
    });

    return response.text;
  }

  async generateSpeech(text: string) {
    const response = await this.client.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } }
            }
        }
    });
    
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  }
}
