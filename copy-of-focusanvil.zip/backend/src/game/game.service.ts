import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class GameService {
  constructor(private prisma: PrismaService) {}

  async completeTask(userId: string, taskId: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return this.prisma.$transaction(async (tx) => {
      const task = await tx.task.findUnique({ where: { id: taskId } });
      if (!task || task.isCompleted) return; // Idempotency check

      // Formula: XP = Weight * 10 (or coin * 2)
      const xpReward = (task.weight || 1) * 10;
      const coinReward = task.coinReward;

      // 1. Mark Task
      await tx.task.update({
        where: { id: taskId },
        data: { isCompleted: true, completedAt: new Date() }
      });

      // 2. Update User Stats
      const stats = await tx.userStats.update({
        where: { userId },
        data: {
          coins: { increment: coinReward },
          xp: { increment: xpReward },
          tasksCompleted: { increment: 1 }
        }
      });

      // 3. Check Level Up
      const newLevel = Math.floor(stats.xp / 1000) + 1;
      if (newLevel > stats.level) {
        await tx.userStats.update({
          where: { userId },
          data: { level: newLevel }
        });
      }

      // 4. Update Heatmap (DailyRecord)
      await tx.dailyRecord.upsert({
        where: { userId_date: { userId, date: today } },
        create: {
          userId,
          date: today,
          tasksCompleted: 1,
          coinsEarned: coinReward,
          productivityScore: 10 // Base bump
        },
        update: {
          tasksCompleted: { increment: 1 },
          coinsEarned: { increment: coinReward },
          productivityScore: { increment: 10 }
        }
      });

      return { stats, newLevel };
    });
  }
}
