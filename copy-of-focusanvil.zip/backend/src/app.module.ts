
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthService } from './auth/auth.service'; 
import { GameService } from './game/game.service'; 
import { SessionsService } from './sessions/sessions.service'; 
import { MentorService } from './mentor/mentor.service'; 
import { PrismaService } from './prisma.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    // Feature modules would be imported here in a full setup
  ],
  controllers: [],
  providers: [PrismaService, AuthService, GameService, SessionsService, MentorService],
})
export class AppModule {}
