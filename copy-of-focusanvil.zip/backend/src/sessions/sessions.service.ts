
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class SessionsService {
  constructor(private prisma: PrismaService) {}

  async abortSession(userId: string, durationMin: number) {
    const PENALTY = 50;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return this.prisma.$transaction(async (tx) => {
      // 1. Deduct Coins
      await tx.userStats.update({
        where: { userId },
        data: { coins: { decrement: PENALTY } }
      });

      // 2. Log Session
      await tx.deepWorkSession.create({
        data: {
          userId,
          durationMin,
          status: 'ABORTED',
          coinsChange: -PENALTY
        }
      });

      // 3. Update Daily Record & Check Streak Kill
      const record = await tx.dailyRecord.upsert({
        where: { userId_date: { userId, date: today } },
        create: { userId, date: today, aborts: 1, violations: 1, productivityScore: -50 },
        update: {
          aborts: { increment: 1 },
          violations: { increment: 1 },
          productivityScore: { decrement: 50 }
        }
      });

      // RUTHLESS: If > 1 abort today, kill streak
      if (record.aborts >= 2) {
        await tx.userStats.update({
          where: { userId },
          data: { streak: 0 }
        });
      }

      return { aborted: true, penalty: PENALTY };
    });
  }

  async completeSession(userId: string, durationMin: number) {
    const coinsEarned = Math.floor(durationMin * 1); // 1 Coin per minute
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return this.prisma.$transaction(async (tx) => {
      await tx.userStats.update({
        where: { userId },
        data: {
          coins: { increment: coinsEarned },
          totalFocusMins: { increment: durationMin },
          xp: { increment: durationMin * 5 }
        }
      });

      await tx.deepWorkSession.create({
        data: {
          userId,
          durationMin,
          status: 'COMPLETED',
          coinsChange: coinsEarned
        }
      });

      await tx.dailyRecord.upsert({
        where: { userId_date: { userId, date: today } },
        create: { userId, date: today, focusMinutes: durationMin, coinsEarned, productivityScore: Math.floor(durationMin/2) },
        update: {
          focusMinutes: { increment: durationMin },
          coinsEarned: { increment: coinsEarned },
          productivityScore: { increment: Math.floor(durationMin/2) }
        }
      });
    });
  }
}
