
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BrainCircuit, ListTodo, MessageSquare, Settings, Zap } from 'lucide-react';

import Dashboard from './components/Dashboard';
import DeepWorkSession from './components/DeepWorkSession';
import MentorChat from './components/MentorChat';
import TaskList from './components/TaskList';
import LandingPage from './components/LandingPage';
import MorningBriefing from './components/MorningBriefing';

import { UserStats, Task, User } from './types';
import { getCurrentUser, shouldGenerateDailyMessage, saveDailyMessage, getStoredDailyMessage, checkLoginStreak, recordDailyActivity, loginUser, getUserStats } from './services/userService';
import { generateMorningMotivation } from './services/geminiService';

// --- Main App Layout Component ---
const AppLayout = ({ stats, user, missedLogin }: { stats: UserStats, user: User | null, missedLogin: boolean }) => {
  const navigate = useNavigate();
  const [morningMessage, setMorningMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    const checkMorningMessage = async () => {
      if (missedLogin) {
        const scoldPrompt = `USER MISSED A DAY. They broke their streak. Goal: ${user.primaryGoal}. SCREAM AT THEM.`;
        const msg = await generateMorningMotivation(scoldPrompt, { streak: 0 }); 
        saveDailyMessage(msg);
        setMorningMessage(msg);
      } else if (shouldGenerateDailyMessage()) {
        // Pass streak logic
        const msg = await generateMorningMotivation(user.primaryGoal, { streak: user.loginStreak });
        saveDailyMessage(msg);
        setMorningMessage(msg);
      }
    };
    
    checkMorningMessage();
  }, [user, navigate, missedLogin]);

  const NavItem = ({ to, icon: Icon, label }: { to: string, icon: any, label: string }) => (
    <NavLink 
        to={to}
        className={({ isActive }) => 
            `flex flex-col items-center gap-1 p-3 rounded-xl transition-all duration-200 ${
                isActive 
                ? 'bg-emerald-600/10 text-emerald-500 border border-emerald-600/20 shadow-[0_0_15px_rgba(16,185,129,0.2)]' 
                : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`
        }
    >
        <Icon size={24} strokeWidth={2} />
        <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
    </NavLink>
  );

  return (
      <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans flex flex-col md:flex-row overflow-hidden">
        
        {morningMessage && (
          <MorningBriefing 
            message={morningMessage} 
            onAcknowledge={() => setMorningMessage(null)} 
          />
        )}

        {/* Sidebar (Desktop) / Bottom Nav (Mobile) */}
        <nav className="order-2 md:order-1 w-full md:w-24 bg-zinc-950 border-t md:border-t-0 md:border-r border-zinc-800 shrink-0 z-20">
            <div className="h-full flex md:flex-col items-center justify-evenly md:justify-start md:py-8 gap-2 md:gap-6">
                <div className="hidden md:flex items-center justify-center w-12 h-12 bg-zinc-900 rounded-full mb-6 border border-zinc-700">
                    <Zap size={24} className="text-white" fill="currentColor" />
                </div>

                <NavItem to="/app" icon={LayoutDashboard} label="Base" />
                <NavItem to="/app/focus" icon={BrainCircuit} label="Focus" />
                <NavItem to="/app/grind" icon={ListTodo} label="Grind" />
                <NavItem to="/app/mentor" icon={MessageSquare} label="Mentor" />
            </div>
        </nav>

        <main className="order-1 md:order-2 flex-1 flex flex-col h-[calc(100vh-80px)] md:h-screen overflow-hidden relative bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-opacity-20">
           <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-950/80 backdrop-blur-md z-10 shrink-0">
              <div className="flex items-center gap-2">
                  <Zap size={20} className="text-emerald-500 md:hidden" fill="currentColor" />
                  <span className="font-mono font-bold text-lg tracking-tighter">FOCUSANVIL<span className="text-emerald-500">.OS</span></span>
              </div>
              <div className="flex items-center gap-4">
                 {user && (
                   <div className="hidden md:flex flex-col items-end mr-4">
                     <span className="text-xs text-zinc-500 font-mono">OPERATOR</span>
                     <span className="text-white font-bold text-sm">{user.email?.split('@')[0] || 'User'}</span>
                   </div>
                 )}
                 <div className="flex flex-col items-end">
                    <span className="text-xs text-zinc-500 font-mono">XP / COINS</span>
                    <div className="flex items-center gap-2">
                      <span className="text-purple-400 font-mono font-bold text-sm">{stats.xp} XP</span>
                      <span className="text-zinc-600">|</span>
                      <span className="text-yellow-400 font-mono font-bold text-sm">{stats.coins} CP</span>
                    </div>
                 </div>
                 <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center hover:bg-zinc-700 cursor-pointer transition-colors">
                    <Settings size={16} className="text-zinc-400" />
                 </div>
              </div>
           </header>

           <div className="flex-1 overflow-y-auto p-4 md:p-8 max-w-7xl mx-auto w-full">
               <Outlet />
           </div>
        </main>
      </div>
  );
};

const App = () => {
  const [stats, setStats] = useState<UserStats>({
    coins: 0,
    xp: 0,
    streak: 0,
    deepWorkMinutes: 0,
    tasksCompleted: 0,
    level: 1,
    history: []
  });

  const [user, setUser] = useState<User | null>(getCurrentUser());
  const [missedLogin, setMissedLogin] = useState(false);
  
  useEffect(() => {
    const u = getCurrentUser();
    if (u) {
        const { updatedUser, missedDay } = checkLoginStreak(u);
        setUser(updatedUser);
        setMissedLogin(missedDay);
        
        const loadedStats = getUserStats();
        if (loadedStats) {
             setStats({
                 ...loadedStats,
                 streak: updatedUser.loginStreak 
             });
        }
    }
  }, []); 

  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Finish System Architecture Diagram', completed: false, coinReward: 50 },
  ]);

  const handleLogin = (u: User) => {
      setUser(u);
      const s = getUserStats();
      if (s) setStats(s);
  };
  
  const handleTaskToggle = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const isCompleting = !t.completed;
        const xpReward = Math.floor(t.coinReward * 2); 

        let newStats = { ...stats };

        if (isCompleting) {
             const newXp = stats.xp + xpReward;
             newStats = {
               ...stats, 
               coins: stats.coins + t.coinReward, 
               xp: newXp,
               tasksCompleted: stats.tasksCompleted + 1,
               level: Math.floor(newXp / 1000) + 1
             };
             // Real-time heatmap update
             newStats = recordDailyActivity(newStats, { tasks: 1, coins: t.coinReward });
        } else {
             const newXp = Math.max(0, stats.xp - xpReward);
             newStats = { 
               ...stats, 
               coins: Math.max(0, stats.coins - t.coinReward), 
               xp: newXp,
               tasksCompleted: Math.max(0, stats.tasksCompleted - 1),
               level: Math.floor(newXp / 1000) + 1
             };
        }
        setStats(newStats);
        return { ...t, completed: isCompleting };
      }
      return t;
    }));
  };

  const handleTaskAdd = (title: string) => {
    const newTask: Task = {
      id: Date.now().toString(),
      title,
      completed: false,
      coinReward: 25 
    };
    setTasks([...tasks, newTask]);
  };

  const handleTaskDelete = (id: string) => {
      setTasks(prev => prev.filter(t => t.id !== id));
  };

  const handleSessionComplete = (mins: number) => {
      const minutes = Math.floor(mins);
      const xpEarned = minutes * 5;
      const coinsEarned = minutes * 2;

      let newStats = { ...stats };
      const newXp = stats.xp + xpEarned;
      
      newStats = {
          ...stats,
          deepWorkMinutes: stats.deepWorkMinutes + minutes,
          coins: stats.coins + coinsEarned,
          xp: newXp,
          level: Math.floor(newXp / 1000) + 1
      };
      
      // Update Heatmap
      newStats = recordDailyActivity(newStats, { minutes, coins: coinsEarned });
      setStats(newStats);
  };

  const handleSessionAbort = () => {
      const penalty = 50;
      
      // Find today's abort count
      const todayStr = new Date().toISOString().split('T')[0];
      const record = stats.history.find(h => h.date === todayStr);
      const currentAborts = (record?.aborts || 0) + 1;

      // Configurable rule: Multiple aborts break streak
      const streakBroken = currentAborts >= 2;

      let newStats = {
          ...stats,
          coins: Math.max(0, stats.coins - penalty),
          streak: streakBroken ? 0 : stats.streak,
      };
      
      // Record Violation & Abort
      newStats = recordDailyActivity(newStats, { violations: 1, aborts: 1 });
      setStats(newStats);
  };

  return (
    <HashRouter>
        <Routes>
            <Route path="/" element={<LandingPage onLogin={handleLogin} />} />
            <Route path="/app" element={<AppLayout stats={stats} user={user} missedLogin={missedLogin} />}>
                <Route index element={<Dashboard stats={stats} tasks={tasks} />} />
                <Route path="focus" element={<DeepWorkSession onSessionComplete={handleSessionComplete} onSessionAbort={handleSessionAbort} />} />
                <Route path="grind" element={<TaskList tasks={tasks} onToggle={handleTaskToggle} onAdd={handleTaskAdd} onDelete={handleTaskDelete} />} />
                <Route path="mentor" element={<MentorChat />} />
            </Route>
        </Routes>
    </HashRouter>
  );
};

export default App;
