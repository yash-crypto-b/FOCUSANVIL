import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Zap, 
  Flame, 
  BrainCircuit, 
  Target, 
  ShieldAlert, 
  Lock, 
  ArrowRight, 
  CheckCircle2,
  Play,
  Trophy,
  ChevronRight,
  Users,
  HelpCircle
} from 'lucide-react';
import { loginUser } from '../services/userService';
import { User } from '../types';

interface LandingPageProps {
  onLogin?: (user: User) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [goal, setGoal] = useState('');
  const [step, setStep] = useState(1);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const handleLogin = () => {
    if (email && goal) {
      const { user } = loginUser(email, goal);
      if (onLogin) {
        onLogin(user);
      }
      navigate('/app');
    }
  };

  const handleNextStep = () => {
    if (step === 1 && email.includes('@')) {
        setStep(2);
    }
  };

  const faqs = [
    {
      q: "Is the mentor actually abusive?",
      a: "The mentor is designed to be ruthless, not malicious. It uses harsh motivation (think J.K. Simmons in Whiplash) because 'gentle parenting' clearly hasn't worked for you. You can switch to a Tactical mode if you prefer cold logic over shouting."
    },
    {
      q: "What happens in Nuclear Mode?",
      a: "Everything shuts down. You cannot exit the session without a penalty. If you try to leave, the app detects the loss of focus, fines you coins, breaks your streak, and the mentor will scold you audibly."
    },
    {
      q: "Is my data safe?",
      a: "Yes. We prioritize local-first storage. Your goals and failures are stored on your device. We don't sell your data; we just use it to shame you into productivity."
    },
    {
      q: "Can I use this if I don't have ADHD?",
      a: "You can, but be warned: this tool is built for people who need extreme structure. If you can work without someone screaming at you, this might be overkill."
    }
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-500/30">
      
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="text-emerald-500" fill="currentColor" size={24} />
            <span className="font-mono font-bold text-xl tracking-tighter">FOCUSANVIL</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#proof" className="hover:text-white transition-colors">Results</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </div>
          <button 
            onClick={() => document.getElementById('signup')?.scrollIntoView({behavior: 'smooth'})}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2 rounded-lg font-bold text-sm transition-all hover:scale-105"
          >
            Launch App
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative overflow-hidden pt-20 pb-32 border-b border-zinc-800">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-full bg-emerald-500/10 blur-3xl -z-10" />
        
        <div className="max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-400 text-xs font-mono mb-8">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            NUCLEAR MODE NOW AVAILABLE
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-tight">
            A ruthless mentor that <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-600">
              forces productivity.
            </span>
          </h1>
          
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Stop negotiating with your laziness. FOCUSANVIL combines deep work enforcement, gamification, and a merciless AI mentor to break your addiction to distraction.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => document.getElementById('signup')?.scrollIntoView({behavior: 'smooth'})}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:scale-105 shadow-[0_0_30px_rgba(16,185,129,0.3)] flex items-center justify-center gap-2"
            >
              Start Building Discipline <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Stats / Trust Banner */}
      <div className="border-b border-zinc-800 bg-zinc-900/30 py-8">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
                <div className="text-3xl font-mono font-bold text-white mb-1">1.2M+</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider">Focus Minutes</div>
            </div>
            <div>
                <div className="text-3xl font-mono font-bold text-white mb-1">85k</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider">Coins Lost</div>
            </div>
            <div>
                <div className="text-3xl font-mono font-bold text-white mb-1">4.2k</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider">Users Broken</div>
            </div>
            <div>
                <div className="text-3xl font-mono font-bold text-white mb-1">98%</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider">Success Rate</div>
            </div>
        </div>
      </div>

      {/* UI Showcase Grid */}
      <section id="features" className="py-24 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">We gamified the grind.</h2>
            <p className="text-zinc-400">Every feature is designed to make focus addictive.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 hover:border-emerald-500/30 transition-colors">
              <div className="mb-6 bg-zinc-950 border border-zinc-800 rounded-xl p-4">
                 <div className="flex items-center gap-2 mb-3 text-sm font-bold text-emerald-400">
                    <Flame size={16} /> Consistency Streak
                 </div>
                 <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: 28 }).map((_, i) => (
                        <div key={i} className={`aspect-square rounded-sm ${Math.random() > 0.3 ? 'bg-emerald-500/80' : 'bg-zinc-800'}`} />
                    ))}
                 </div>
              </div>
              <h3 className="text-xl font-bold mb-2">Visual Consistency</h3>
              <p className="text-zinc-400 leading-relaxed">
                Don't break the chain. Your dashboard tracks every productive day on a live heatmap. Gaps are failures.
              </p>
            </div>

            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 hover:border-red-500/30 transition-colors relative overflow-hidden">
              <div className="mb-6 bg-zinc-950 border border-zinc-800 rounded-xl p-4 relative">
                 <div className="absolute inset-0 bg-red-900/10 animate-pulse" />
                 <div className="text-center py-6">
                    <div className="text-4xl font-mono font-bold text-red-500 mb-2">24:59</div>
                    <div className="text-xs font-bold text-red-400 uppercase tracking-widest">Nuclear Mode Active</div>
                 </div>
              </div>
              <h3 className="text-xl font-bold mb-2">Nuclear Enforcement</h3>
              <p className="text-zinc-400 leading-relaxed">
                Lock your device. If you leave the session, the timer resets, you lose coins, and the mentor insults you.
              </p>
            </div>

            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 hover:border-yellow-500/30 transition-colors">
              <div className="mb-6 bg-zinc-950 border border-zinc-800 rounded-xl p-4 flex flex-col gap-3">
                 <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                    <span className="text-sm text-zinc-300">Finish API Spec</span>
                    <span className="text-yellow-500 font-mono text-xs font-bold">+50 CP</span>
                 </div>
                 <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                    <span className="text-sm text-zinc-500 line-through">Workout</span>
                    <span className="text-emerald-500 font-mono text-xs font-bold">DONE</span>
                 </div>
                 <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-300">Study Algorithms</span>
                    <span className="text-yellow-500 font-mono text-xs font-bold">+100 CP</span>
                 </div>
              </div>
              <h3 className="text-xl font-bold mb-2">Currency & Rewards</h3>
              <p className="text-zinc-400 leading-relaxed">
                Earn coins for every minute of focus. Spend them to buy "Snooze" tokens or cosmetic upgrades.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section id="proof" className="py-24 border-t border-zinc-900 bg-zinc-900/20">
        <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-16">They hated it. Then they succeeded.</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                    { quote: "I cried when the mentor deleted my coins because I checked Instagram. I haven't checked it since.", author: "Sarah J., Dev", role: "Recovering Procrastinator" },
                    { quote: "It's not an app. It's a digital bully. And it's the only reason I shipped my MVP.", author: "Marcus T.", role: "Founder" },
                    { quote: "Nuclear mode is terrifying. I actually get work done now because I'm scared to fail.", author: "Alex R.", role: "ADHD User" }
                ].map((t, i) => (
                    <div key={i} className="bg-zinc-950 border border-zinc-800 p-8 rounded-2xl relative hover:scale-105 transition-transform duration-300">
                        <div className="absolute -top-4 -left-2 text-6xl text-zinc-800 font-serif opacity-50">"</div>
                        <p className="text-zinc-300 mb-6 italic relative z-10 leading-relaxed">"{t.quote}"</p>
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500">
                                <Users size={18} />
                            </div>
                            <div>
                                <div className="font-bold text-white">{t.author}</div>
                                <div className="text-xs text-zinc-500 uppercase tracking-wider">{t.role}</div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-24 border-t border-zinc-900">
        <div className="max-w-3xl mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-16 flex items-center justify-center gap-3">
                <HelpCircle /> Frequently Asked Questions
            </h2>
            <div className="space-y-4">
                {faqs.map((faq, i) => (
                    <div key={i} className="bg-zinc-900/40 border border-zinc-800 rounded-xl overflow-hidden">
                        <button 
                            onClick={() => setOpenFaq(openFaq === i ? null : i)}
                            className="w-full px-6 py-4 text-left flex justify-between items-center font-bold text-zinc-200 hover:bg-zinc-800/50 transition-colors"
                        >
                            {faq.q}
                            <ChevronRight size={20} className={`transition-transform ${openFaq === i ? 'rotate-90 text-emerald-500' : 'text-zinc-500'}`} />
                        </button>
                        {openFaq === i && (
                            <div className="px-6 pb-4 text-zinc-400 leading-relaxed animate-in slide-in-from-top-2">
                                {faq.a}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* Footer / Sign Up */}
      <footer id="signup" className="bg-zinc-950 pt-20 pb-10 border-t border-zinc-900">
        <div className="max-w-xl mx-auto px-6 text-center">
            <h2 className="text-2xl font-bold mb-2">Join the war on distraction.</h2>
            <p className="text-zinc-500 mb-8">Tell the Mentor your goal. He will ensure you reach it.</p>
            
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-12 shadow-2xl text-left">
                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-2 text-xs font-bold text-zinc-500 uppercase tracking-wider">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white ${step >= 1 ? 'bg-emerald-600' : 'bg-zinc-800'}`}>1</div>
                        Identify
                    </div>
                    <input 
                        type="email" 
                        placeholder="enter@your.email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        disabled={step > 1}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 focus:ring-1 focus:ring-emerald-500 outline-none disabled:opacity-50 text-white"
                    />
                </div>

                {step === 1 && (
                    <button 
                        onClick={handleNextStep}
                        disabled={!email}
                        className="w-full bg-zinc-100 hover:bg-white disabled:bg-zinc-700 disabled:text-zinc-500 text-zinc-950 font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                        Next <ChevronRight size={16} />
                    </button>
                )}

                {step === 2 && (
                    <div className="animate-in slide-in-from-bottom-4 fade-in duration-300">
                        <div className="flex items-center gap-2 mb-2 text-xs font-bold text-zinc-500 uppercase tracking-wider">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white ${goal ? 'bg-emerald-600' : 'bg-zinc-800'}`}>2</div>
                            Your Mission
                        </div>
                        <textarea
                            placeholder="I need to build my startup MVP by next month..."
                            value={goal}
                            onChange={(e) => setGoal(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 focus:ring-1 focus:ring-emerald-500 outline-none min-h-[100px] text-white mb-4"
                        />
                        <button 
                            onClick={handleLogin}
                            disabled={!goal}
                            className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-bold py-3 rounded-lg transition-colors"
                        >
                            Enter Protocol
                        </button>
                    </div>
                )}
            </div>

            <div className="flex items-center justify-center gap-2 mb-8 text-zinc-600">
                <Zap size={16} />
                <span className="font-mono font-bold text-lg tracking-tighter">FOCUSANVIL</span>
            </div>
            <p className="text-zinc-700 text-xs">
                © 2025 FocusAnvil Inc. No excuses reserved.
            </p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;