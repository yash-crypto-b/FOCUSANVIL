import React, { useState, useRef, useEffect } from 'react';
import { Send, Volume2, Loader2, Bot } from 'lucide-react';
import { ChatMessage, MentorPersonality } from '../types';
import { chatWithMentor, generateMentorSpeech, playAudioData } from '../services/geminiService';
import { getCurrentUser } from '../services/userService';

const MentorChat: React.FC = () => {
  const [input, setInput] = useState('');
  const [personality, setPersonality] = useState<MentorPersonality>(MentorPersonality.RUTHLESS);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      text: "NOT MY TEMPO! You are late. You are sloppy. And you are wasting my time. STATE YOUR OBJECTIVE OR GET OUT OF MY SIGHT.",
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  
  // Get User Goal Context
  const user = getCurrentUser();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // Prepare history for API
    const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
    }));

    const responseText = await chatWithMentor(input, personality, history, user?.primaryGoal);

    const aiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, aiMsg]);
    setIsLoading(false);
  };

  const handleSpeak = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    
    if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }

    const buffer = await generateMentorSpeech(text, personality);
    if (buffer && audioContextRef.current) {
        await playAudioData(buffer, audioContextRef.current);
    }
    setIsSpeaking(false);
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden shadow-2xl">
      
      {/* Header */}
      <div className="p-4 border-b border-zinc-800 bg-zinc-950 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-900 flex items-center justify-center border border-red-700">
            <Bot className="text-red-200" size={20} />
          </div>
          <div>
            <h3 className="font-bold text-white">FOCUSANVIL Mentor</h3>
            <select 
                value={personality}
                onChange={(e) => setPersonality(e.target.value as MentorPersonality)}
                className="text-xs bg-transparent text-zinc-500 border-none outline-none cursor-pointer hover:text-zinc-300"
            >
                {Object.values(MentorPersonality).map(p => (
                    <option key={p} value={p} className="bg-zinc-900">{p}</option>
                ))}
            </select>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl p-4 ${
              msg.role === 'user' 
                ? 'bg-zinc-800 text-white rounded-tr-none' 
                : 'bg-gradient-to-br from-red-950 to-zinc-900 border border-red-900/30 text-zinc-100 rounded-tl-none shadow-lg'
            }`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              
              {msg.role === 'model' && (
                <button 
                    onClick={() => handleSpeak(msg.text)}
                    disabled={isSpeaking}
                    className="mt-2 flex items-center gap-1 text-xs text-red-400/70 hover:text-red-400 transition-colors"
                >
                    <Volume2 size={12} /> {isSpeaking ? 'Speaking...' : 'Listen'}
                </button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 rounded-tl-none flex items-center gap-2 text-zinc-500 text-sm">
                <Loader2 className="animate-spin" size={16} /> Glaring at you...
             </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 bg-zinc-950 border-t border-zinc-800">
        <div className="flex gap-2">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Make an excuse or ask for orders..."
            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all placeholder:text-zinc-600"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-lg transition-colors"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MentorChat;