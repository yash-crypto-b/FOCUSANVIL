
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, AlertTriangle, XCircle, Radio, AlertOctagon, Skull, Clock } from 'lucide-react';
import { generateMentorSpeech, playAudioData } from '../services/geminiService';
import { MentorPersonality } from '../types';

interface DeepWorkSessionProps {
  onSessionComplete: (duration: number) => void;
  onSessionAbort: () => void;
}

const DeepWorkSession: React.FC<DeepWorkSessionProps> = ({ onSessionComplete, onSessionAbort }) => {
  const [status, setStatus] = useState<'IDLE' | 'RUNNING' | 'PAUSED'>('IDLE');
  const [duration, setDuration] = useState(25 * 60);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isNuclear, setIsNuclear] = useState(false);
  const [showAbortModal, setShowAbortModal] = useState(false);
  
  // Custom time state
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [customInput, setCustomInput] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    let interval: number | undefined;

    if (status === 'RUNNING' && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && status !== 'IDLE') {
      setStatus('IDLE');
      setIsNuclear(false);
      onSessionComplete(duration / 60);
    }

    return () => clearInterval(interval);
  }, [status, timeLeft, onSessionComplete, duration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setStatus('RUNNING');
    setIsNuclear(true);
  };

  const handlePauseToggle = () => {
    if (status === 'IDLE') return;
    setStatus(prev => prev === 'RUNNING' ? 'PAUSED' : 'RUNNING');
  };

  const handleCustomTimeSet = () => {
    const minutes = parseInt(customInput);
    if (!isNaN(minutes) && minutes > 0) {
        const seconds = minutes * 60;
        setDuration(seconds);
        setTimeLeft(seconds);
        setIsCustomizing(false);
    }
  };

  const triggerScolding = async () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    try {
      const speechBuffer = await generateMentorSpeech(
        "WEAK START! MISSION ABORTED. I TOOK YOUR COINS. GET BACK IN THERE AND STOP WASTING MY TIME!",
        MentorPersonality.RUTHLESS
      );
      
      if (speechBuffer && audioContextRef.current) {
        await playAudioData(speechBuffer, audioContextRef.current);
      }
    } catch (error) {
      console.error("Scolding error:", error);
    }
  };

  const confirmAbort = () => {
    setShowAbortModal(false);
    const wasNuclear = isNuclear;
    setStatus('IDLE');
    setIsNuclear(false);
    setTimeLeft(duration); // Reset timer
    
    onSessionAbort(); // Trigger penalty logic in App

    if (wasNuclear) {
      triggerScolding();
    }
  };

  return (
    <div className={`flex flex-col items-center justify-center h-full w-full transition-colors duration-700 ${isNuclear ? 'bg-red-950/30' : 'bg-transparent'}`}>
      
      <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 shadow-2xl w-full max-w-md flex flex-col items-center relative overflow-hidden">
        
        {isNuclear && (
            <div className="absolute top-0 left-0 w-full bg-red-600 text-white text-center text-xs font-bold py-1 uppercase tracking-[0.3em] animate-pulse">
                Nuclear Mode Active
            </div>
        )}

        <div className="mt-6 mb-8 relative">
          <div className={`w-64 h-64 rounded-full border-4 flex items-center justify-center relative transition-colors duration-500 ${isNuclear ? 'border-red-600 bg-red-950/10' : 'border-emerald-500 bg-emerald-950/10'}`}>
             {status === 'RUNNING' && (
                 <div className={`absolute inset-0 rounded-full border-4 border-t-transparent animate-spin ${isNuclear ? 'border-red-400' : 'border-emerald-300'}`} />
             )}
             <span className={`text-6xl font-mono font-bold ${isNuclear ? 'text-red-500' : 'text-white'} ${status === 'PAUSED' ? 'opacity-50' : ''}`}>
                {formatTime(timeLeft)}
             </span>
             {status === 'PAUSED' && (
                 <div className="absolute inset-0 flex items-center justify-center">
                     <span className="bg-zinc-900/80 text-white text-xs font-bold px-2 py-1 rounded uppercase tracking-widest">Paused</span>
                 </div>
             )}
          </div>
        </div>

        {status === 'IDLE' ? (
            <div className="space-y-4 w-full">
                <div className="flex flex-wrap justify-between gap-2">
                    {[15, 25, 45, 60].map(m => (
                        <button 
                            key={m}
                            onClick={() => { setDuration(m*60); setTimeLeft(m*60); setIsCustomizing(false); }}
                            className={`flex-1 py-2 rounded text-sm font-bold font-mono border transition-colors ${duration === m*60 && !isCustomizing ? 'bg-zinc-100 text-zinc-900 border-zinc-100' : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:bg-zinc-700'}`}
                        >
                            {m}m
                        </button>
                    ))}
                    <button
                        onClick={() => setIsCustomizing(!isCustomizing)}
                        className={`px-3 py-2 rounded text-sm font-bold font-mono border transition-colors ${isCustomizing ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:bg-zinc-700'}`}
                    >
                        <Clock size={16} />
                    </button>
                </div>

                {isCustomizing && (
                    <div className="flex gap-2 animate-in fade-in slide-in-from-top-1">
                        <input
                            type="number"
                            value={customInput}
                            onChange={(e) => setCustomInput(e.target.value)}
                            placeholder="Minutes..."
                            className="flex-1 bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white text-sm focus:border-emerald-500 outline-none font-mono"
                            onKeyDown={(e) => { if (e.key === 'Enter') handleCustomTimeSet(); }}
                        />
                        <button
                            onClick={handleCustomTimeSet}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded text-sm font-bold"
                        >
                            Set
                        </button>
                    </div>
                )}

                <button 
                    onClick={handleStart}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xl uppercase tracking-widest rounded-lg flex items-center justify-center gap-3 transition-all hover:scale-105 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
                >
                    <Play size={24} fill="currentColor" /> Initiate
                </button>
            </div>
        ) : (
            <div className="space-y-4 w-full text-center">
                <div className="text-zinc-500 text-sm font-mono mb-4 flex items-center justify-center gap-2">
                    <Skull size={14} /> NO EXIT WITHOUT PENALTY
                </div>
                
                <div className="flex gap-4">
                    <button 
                        onClick={handlePauseToggle}
                        className="flex-1 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-lg flex items-center justify-center gap-2 border border-zinc-700"
                    >
                        {status === 'RUNNING' ? <Pause size={20} /> : <Play size={20} />} 
                        {status === 'RUNNING' ? 'Pause' : 'Resume'}
                    </button>
                    <button 
                        onClick={() => setShowAbortModal(true)}
                        className="flex-1 py-3 bg-red-950 hover:bg-red-900 text-red-500 border border-red-800 font-bold rounded-lg flex items-center justify-center gap-2 transition-colors hover:shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                    >
                        <XCircle size={20} /> ABORT MISSION
                    </button>
                </div>
            </div>
        )}

        {/* Status Footer */}
        <div className="mt-8 flex items-center gap-2 text-zinc-500 text-xs font-mono">
            <Radio size={12} className={status === 'RUNNING' ? "animate-ping text-red-500" : ""} />
            STATUS: {status === 'IDLE' ? "IDLE" : status === 'RUNNING' ? "LOCKED IN" : "HOLDING PATTERN"}
        </div>
      </div>

      {/* Abort Confirmation Modal */}
      {showAbortModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-zinc-950 border border-red-600 w-full max-w-sm rounded-2xl p-6 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-red-600 animate-pulse" />
                
                <div className="flex flex-col items-center text-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mb-4 border border-red-500/50">
                        <AlertOctagon size={32} className="text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">ABORT MISSION?</h3>
                    <p className="text-zinc-400 text-sm">
                        This action will cost <span className="text-red-400 font-bold">50 Coins</span> and disappoint your mentor.
                    </p>
                </div>
                
                <div className="flex flex-col gap-3">
                    <button 
                        onClick={confirmAbort}
                        className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg uppercase tracking-widest shadow-lg shadow-red-900/30"
                    >
                        Yes, Abort
                    </button>
                    <button 
                        onClick={() => setShowAbortModal(false)}
                        className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-lg uppercase tracking-widest border border-zinc-700"
                    >
                        No, Return to Focus
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default DeepWorkSession;
