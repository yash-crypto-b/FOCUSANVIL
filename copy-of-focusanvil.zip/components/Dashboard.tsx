
import React from 'react';
import { UserStats, Task } from '../types';
import { Flame, Trophy, Play, Zap, Activity, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { useNavigate } from 'react-router-dom';

interface DashboardProps {
  stats: UserStats;
  tasks: Task[];
}

const Dashboard: React.FC<DashboardProps> = ({ stats, tasks }) => {
  const navigate = useNavigate();
  
  // Calculate Today's Hours
  const todayStr = new Date().toISOString().split('T')[0];
  const todayRecord = stats.history.find(h => h.date === todayStr);
  const todayMinutes = todayRecord ? todayRecord.focusMinutes : 0;
  const hours = Math.floor(todayMinutes / 60);
  const mins = todayMinutes % 60;
  const todayTimeString = `${hours}h ${mins}m`;

  // Prepare Data for Trend Graph (Last 14 Days)
  const trendData = [];
  for(let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const record = stats.history.find(h => h.date === dateStr);
      trendData.push({
          name: dateStr.slice(5), // MM-DD
          minutes: record ? record.focusMinutes : 0,
          score: record ? record.productivityScore : 0
      });
  }

  // Generate Heatmap Grid (Last 35 days)
  const renderHeatmap = () => {
    const days = [];
    const today = new Date();
    
    for (let i = 34; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      const record = stats.history.find(h => h.date === dateStr);
      const score = record ? record.productivityScore : 0; // 0-100
      
      let colorClass = 'bg-zinc-900';
      if (score > 0) {
          if (score >= 80) colorClass = 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.4)]';
          else if (score >= 50) colorClass = 'bg-emerald-600';
          else if (score >= 20) colorClass = 'bg-emerald-800';
          else colorClass = 'bg-emerald-950';
      }
      
      const isToday = i === 0;

      days.push(
        <div 
          key={i} 
          className={`w-full aspect-square rounded-sm ${colorClass} ${isToday ? 'ring-1 ring-white' : ''} hover:scale-125 transition-all duration-200 cursor-pointer relative group border border-zinc-900/50`}
        >
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block bg-zinc-800 text-xs text-white px-2 py-1 rounded whitespace-nowrap z-20 border border-zinc-700 shadow-xl pointer-events-none">
                <div className="font-bold">{dateStr}</div>
                <div>Score: {score}%</div>
                <div>Mins: {record?.focusMinutes || 0}</div>
            </div>
        </div>
      );
    }
    return days;
  };

  const xpForCurrentLevel = (stats.level - 1) * 1000;
  const xpForNextLevel = stats.level * 1000;
  const currentLevelProgress = stats.xp - xpForCurrentLevel;
  const levelProgressPercent = Math.min(100, Math.max(0, (currentLevelProgress / 1000) * 100));

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      
      {/* Hero / CTA Section */}
      <div className="bg-gradient-to-r from-zinc-900 to-zinc-950 border border-zinc-800 p-6 rounded-xl flex flex-col sm:flex-row justify-between items-center relative overflow-hidden group gap-4 shadow-lg">
        <div className="relative z-10 text-center sm:text-left">
          <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-2 justify-center sm:justify-start">
             Ready to Grind? 
          </h2>
          <p className="text-zinc-400 text-sm">Initiate a deep work session to earn coins and secure your streak.</p>
        </div>
        <button
            onClick={() => navigate('/app/focus')}
            className="relative z-10 flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-3 rounded-lg font-bold transition-all hover:scale-105 shadow-lg shadow-emerald-900/20 uppercase tracking-wider whitespace-nowrap"
        >
            <Play size={20} fill="currentColor" />
            Enter Focus Mode
        </button>
        <div className="absolute right-0 top-0 w-64 h-full bg-emerald-500/5 skew-x-[-20deg] group-hover:bg-emerald-500/10 transition-colors pointer-events-none" />
      </div>

      {/* Header Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900 p-4 rounded-xl border border-zinc-800 flex flex-col items-center justify-center group hover:border-amber-500/30 transition-colors">
          <div className="flex items-center gap-2 text-amber-500 mb-1">
            <Flame size={20} className={stats.streak > 0 ? "animate-pulse" : "opacity-50"} />
            <span className="font-bold uppercase text-xs tracking-wider">Streak</span>
          </div>
          <span className="text-3xl font-mono font-bold text-white">{stats.streak} <span className="text-xs text-zinc-600">days</span></span>
        </div>
        
        <div className="bg-zinc-900 p-4 rounded-xl border border-zinc-800 flex flex-col items-center justify-center group hover:border-yellow-500/30 transition-colors">
          <div className="flex items-center gap-2 text-yellow-400 mb-1">
            <Trophy size={20} />
            <span className="font-bold uppercase text-xs tracking-wider">Coins</span>
          </div>
          <span className="text-3xl font-mono font-bold text-white">{stats.coins}</span>
        </div>

        <div className="bg-zinc-900 p-4 rounded-xl border border-zinc-800 flex flex-col items-center justify-center group hover:border-blue-500/30 transition-colors">
          <div className="flex items-center gap-2 text-blue-400 mb-1">
            <Clock size={20} />
            <span className="font-bold uppercase text-xs tracking-wider">Today</span>
          </div>
          <span className="text-3xl font-mono font-bold text-white">{todayTimeString}</span>
        </div>

        <div className="bg-zinc-900 p-4 rounded-xl border border-zinc-800 flex flex-col items-center justify-center relative overflow-hidden group hover:border-purple-500/30 transition-colors">
          <div className="absolute top-0 right-0 p-1">
            <div className="text-[10px] font-bold text-zinc-500">LVL {stats.level}</div>
          </div>
          <div className="flex items-center gap-2 text-purple-400 mb-1">
            <Zap size={20} />
            <span className="font-bold uppercase text-xs tracking-wider">XP</span>
          </div>
          <span className="text-3xl font-mono font-bold text-white">{stats.xp}</span>
        </div>
      </div>

      {/* Level Progress */}
      <div className="bg-zinc-900 p-6 rounded-xl border border-zinc-800">
        <div className="flex justify-between text-sm mb-2 text-zinc-400">
          <span className="font-bold text-white">Level {stats.level}</span>
          <span className="font-mono">{stats.xp} / {xpForNextLevel} XP</span>
        </div>
        <div className="h-4 w-full bg-zinc-800 rounded-full overflow-hidden relative border border-zinc-700">
          <div 
            className="h-full bg-gradient-to-r from-purple-700 to-purple-500 transition-all duration-1000"
            style={{ width: `${levelProgressPercent}%` }}
          />
           <div className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-white/50 uppercase tracking-widest mix-blend-plus-lighter">
              Progress to Level {stats.level + 1}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Heatmap */}
        <div className="bg-zinc-900 p-6 rounded-xl border border-zinc-800">
          <div className="flex justify-between items-center mb-4">
             <h3 className="text-lg font-bold flex items-center gap-2">
               <Flame className="text-danger" size={18} /> Consistency Heatmap
             </h3>
             <span className="text-xs text-zinc-500 bg-zinc-800 px-2 py-1 rounded">Last 35 Days</span>
          </div>
          
          <div className="grid grid-cols-7 gap-2 mb-6">
             {['M','T','W','T','F','S','S'].map((d, i) => (
               <div key={i} className="text-center text-xs text-zinc-500 font-mono font-bold opacity-50">{d}</div>
             ))}
             {renderHeatmap()}
          </div>
          <div className="flex justify-between items-center text-xs text-zinc-500 font-mono">
             <span>Less</span>
             <div className="flex gap-1">
                 <div className="w-3 h-3 bg-emerald-950 rounded-sm"></div>
                 <div className="w-3 h-3 bg-emerald-800 rounded-sm"></div>
                 <div className="w-3 h-3 bg-emerald-600 rounded-sm"></div>
                 <div className="w-3 h-3 bg-emerald-400 rounded-sm"></div>
             </div>
             <span>More</span>
          </div>
        </div>

        {/* Chart */}
        <div className="bg-zinc-900 p-6 rounded-xl border border-zinc-800 h-80">
          <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                  <Activity className="text-blue-400" size={18} /> Focus Trend
              </h3>
              <span className="text-xs text-zinc-500 bg-zinc-800 px-2 py-1 rounded">Minutes / Day</span>
          </div>
          <ResponsiveContainer width="100%" height="80%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis 
                dataKey="name" 
                tick={{fill: '#52525b', fontSize: 10, fontFamily: 'monospace'}} 
                axisLine={false} 
                tickLine={false}
                interval={2} 
              />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ backgroundColor: '#09090b', border: '1px solid #27272a', borderRadius: '8px', color: '#fff' }}
                itemStyle={{ color: '#10b981', fontFamily: 'monospace' }}
                cursor={{stroke: '#3f3f46', strokeWidth: 1}}
              />
              <Area 
                type="monotone" 
                dataKey="minutes" 
                stroke="#10b981" 
                strokeWidth={2} 
                fillOpacity={1} 
                fill="url(#colorScore)" 
                activeDot={{ r: 4, strokeWidth: 0, fill: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
