import React from 'react';
import { Zap, Check, X } from 'lucide-react';

interface MorningBriefingProps {
  message: string;
  onAcknowledge: () => void;
}

const MorningBriefing: React.FC<MorningBriefingProps> = ({ message, onAcknowledge }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-zinc-950 border border-red-900/50 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="bg-red-950/30 border-b border-red-900/30 p-6 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center text-red-500">
            <Zap size={20} fill="currentColor" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">DAILY BRIEFING</h2>
            <p className="text-red-400 text-xs font-mono uppercase tracking-widest">Mentor Protocol Active</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          <div className="text-xl md:text-2xl font-bold text-zinc-200 leading-relaxed font-serif italic">
            "{message}"
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-zinc-900/50 border-t border-zinc-800 flex justify-end">
          <button 
            onClick={onAcknowledge}
            className="bg-zinc-100 hover:bg-white text-zinc-950 px-6 py-3 rounded-lg font-bold flex items-center gap-2 transition-all hover:scale-105"
          >
            <Check size={18} />
            I WILL COMPLY
          </button>
        </div>
      </div>
    </div>
  );
};

export default MorningBriefing;