import React, { useState } from 'react';
import { CheckCircle, Circle, Plus, Trash2, Zap } from 'lucide-react';
import { Task } from '../types';

interface TaskListProps {
  tasks: Task[];
  onToggle: (id: string) => void;
  onAdd: (title: string) => void;
  onDelete: (id: string) => void;
}

const TaskList: React.FC<TaskListProps> = ({ tasks, onToggle, onAdd, onDelete }) => {
  const [newTask, setNewTask] = useState('');

  const handleAdd = () => {
    if (!newTask.trim()) return;
    onAdd(newTask);
    setNewTask('');
  };

  return (
    <div className="bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden h-full flex flex-col">
      <div className="p-4 bg-zinc-950 border-b border-zinc-800 flex justify-between items-center">
        <h3 className="font-bold text-white flex items-center gap-2">
          The Grind
          <span className="bg-zinc-800 text-zinc-400 text-xs px-2 py-0.5 rounded-full">{tasks.filter(t => !t.completed).length}</span>
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {tasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-sm font-mono">
                No orders pending.
            </div>
        ) : (
            <div className="space-y-2">
            {tasks.map(task => {
                const xpReward = Math.floor(task.coinReward * 2);
                return (
                <div 
                    key={task.id} 
                    className={`group flex items-center gap-3 p-3 rounded-lg border transition-all ${
                        task.completed 
                        ? 'bg-zinc-900/50 border-transparent opacity-50' 
                        : 'bg-zinc-800/50 border-zinc-700 hover:bg-zinc-800 hover:border-zinc-600'
                    }`}
                >
                    <button onClick={() => onToggle(task.id)} className={`shrink-0 ${task.completed ? 'text-emerald-500' : 'text-zinc-500 hover:text-emerald-400'}`}>
                        {task.completed ? <CheckCircle size={20} /> : <Circle size={20} />}
                    </button>
                    <span className={`flex-1 text-sm ${task.completed ? 'line-through text-zinc-500' : 'text-zinc-100'}`}>
                        {task.title}
                    </span>
                    <div className="flex items-center gap-3">
                        <span className="text-xs font-mono text-yellow-500/70 flex items-center gap-1">
                            +{task.coinReward} CP
                        </span>
                        <span className="text-xs font-mono text-purple-500/70 flex items-center gap-1">
                            <Zap size={10} /> {xpReward} XP
                        </span>
                    </div>
                    <button onClick={() => onDelete(task.id)} className="opacity-0 group-hover:opacity-100 text-zinc-600 hover:text-red-400 transition-all">
                        <Trash2 size={16} />
                    </button>
                </div>
            )})}
            </div>
        )}
      </div>

      <div className="p-4 border-t border-zinc-800 bg-zinc-950">
        <div className="flex gap-2">
            <input 
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                placeholder="Add new directive..."
                className="flex-1 bg-zinc-900 border-none text-sm text-white focus:ring-1 focus:ring-emerald-600 rounded px-3 py-2"
            />
            <button onClick={handleAdd} className="bg-zinc-800 hover:bg-zinc-700 text-white p-2 rounded">
                <Plus size={18} />
            </button>
        </div>
      </div>
    </div>
  );
};

export default TaskList;