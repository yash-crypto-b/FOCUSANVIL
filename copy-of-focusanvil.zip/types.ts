
export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  DEEP_WORK = 'DEEP_WORK',
  TASKS = 'TASKS',
  MENTOR = 'MENTOR',
  SETTINGS = 'SETTINGS'
}

export interface User {
  email: string;
  primaryGoal: string;
  joinedAt: string; // ISO Date string
  journeyStartDate: string; // ISO Date string of when they actually started the protocol
  lastLoginAt: string;
  loginStreak: number;
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  coinReward: number;
  deadline?: Date;
}

export interface DailyRecord {
  date: string; // YYYY-MM-DD
  focusMinutes: number;
  tasksCompleted: number;
  coinsEarned: number;
  violations: number;
  aborts: number; // Track aborted sessions
  productivityScore: number; // 0-100
}

export interface UserStats {
  coins: number;
  xp: number;
  streak: number;
  deepWorkMinutes: number;
  tasksCompleted: number;
  level: number;
  history: DailyRecord[]; // For heatmap and trend graph
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isAudio?: boolean;
  audioData?: string; // base64
}

export enum MentorPersonality {
  RUTHLESS = 'Simmons Drill Instructor',
  TACTICAL = 'Tactical Strategist',
  SUPPORTIVE = 'Supportive Coach' // Only available for high cost
}
